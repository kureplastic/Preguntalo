
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mi_perfil
	 *	@date 		Thursday 08th of February 2024 02:01:16 AM
	 *	@title 		Ventanas
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class mi_perfil_activity extends Activity {

	
	private View _bg__mi_perfil;
	private View _bg__frame_botones_ek1;
	private View _bg__boton_rating_ek1;
	private View rectangle_5;
	private View _bg__icono_rating_ek1;
	private ImageView icon;
	private View _bg__boton_nueva_consulta_ek1;
	private View rectangle_4;
	private View _bg__boton_perfil_ek1;
	private View rectangle_6;
	private View _bg__icono_user_ek1;
	private ImageView icon_ek1;
	private View _bg__boton_consultas_ek1;
	private View rectangle_3;
	private View _bg__icono_accion_ek1;
	private ImageView combined_shape;
	private View _bg___24___basic___plus_ek1;
	private ImageView icon_ek2;
	private ImageView polygon_1;
	private View _bg__avatar_profile_photo_ek1;
	private View _bg___24___basic___pencil_create;
	private ImageView icon_ek3;
	private TextView nombre__apellidos;
	private TextView tus_profesiones;
	private TextView titulo;
	private TextView descripcion_de_la_profesion_agregada_;
	private View _bg___24___basic___image;
	private ImageView icon_ek4;
	private View _bg___1_0_icon_solid_ek1;
	private TextView icon_ek5;
	private View _bg___24___basic___plus;
	private ImageView icon_ek6;
	private TextView agregar_profesion;
	private TextView descripcion_de_la_profesion_agregada__ek1;
	private View _bg___24___basic___image_ek5;
	private ImageView icon_ek7;
	private View _bg__icon_container_ek1;
	private ImageView __img___1_0_icon_solid;
	private ImageView __img___rectangle_10;
	private ImageView __img___rectangle_11;
	private TextView titulo_ek1;
	private View _bg__email_ek1;
	private ImageView __img___container;
	private View _bg__text_ek1;
	private TextView email_ek2;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.mi_perfil);

		
		_bg__mi_perfil = (View) findViewById(R.id._bg__mi_perfil);
		_bg__frame_botones_ek1 = (View) findViewById(R.id._bg__frame_botones_ek1);
		_bg__boton_rating_ek1 = (View) findViewById(R.id._bg__boton_rating_ek1);
		rectangle_5 = (View) findViewById(R.id.rectangle_5);
		_bg__icono_rating_ek1 = (View) findViewById(R.id._bg__icono_rating_ek1);
		icon = (ImageView) findViewById(R.id.icon);
		_bg__boton_nueva_consulta_ek1 = (View) findViewById(R.id._bg__boton_nueva_consulta_ek1);
		rectangle_4 = (View) findViewById(R.id.rectangle_4);
		_bg__boton_perfil_ek1 = (View) findViewById(R.id._bg__boton_perfil_ek1);
		rectangle_6 = (View) findViewById(R.id.rectangle_6);
		_bg__icono_user_ek1 = (View) findViewById(R.id._bg__icono_user_ek1);
		icon_ek1 = (ImageView) findViewById(R.id.icon_ek1);
		_bg__boton_consultas_ek1 = (View) findViewById(R.id._bg__boton_consultas_ek1);
		rectangle_3 = (View) findViewById(R.id.rectangle_3);
		_bg__icono_accion_ek1 = (View) findViewById(R.id._bg__icono_accion_ek1);
		combined_shape = (ImageView) findViewById(R.id.combined_shape);
		_bg___24___basic___plus_ek1 = (View) findViewById(R.id._bg___24___basic___plus_ek1);
		icon_ek2 = (ImageView) findViewById(R.id.icon_ek2);
		polygon_1 = (ImageView) findViewById(R.id.polygon_1);
		_bg__avatar_profile_photo_ek1 = (View) findViewById(R.id._bg__avatar_profile_photo_ek1);
		_bg___24___basic___pencil_create = (View) findViewById(R.id._bg___24___basic___pencil_create);
		icon_ek3 = (ImageView) findViewById(R.id.icon_ek3);
		nombre__apellidos = (TextView) findViewById(R.id.nombre__apellidos);
		tus_profesiones = (TextView) findViewById(R.id.tus_profesiones);
		titulo = (TextView) findViewById(R.id.titulo);
		descripcion_de_la_profesion_agregada_ = (TextView) findViewById(R.id.descripcion_de_la_profesion_agregada_);
		_bg___24___basic___image = (View) findViewById(R.id._bg___24___basic___image);
		icon_ek4 = (ImageView) findViewById(R.id.icon_ek4);
		_bg___1_0_icon_solid_ek1 = (View) findViewById(R.id._bg___1_0_icon_solid_ek1);
		icon_ek5 = (TextView) findViewById(R.id.icon_ek5);
		_bg___24___basic___plus = (View) findViewById(R.id._bg___24___basic___plus);
		icon_ek6 = (ImageView) findViewById(R.id.icon_ek6);
		agregar_profesion = (TextView) findViewById(R.id.agregar_profesion);
		descripcion_de_la_profesion_agregada__ek1 = (TextView) findViewById(R.id.descripcion_de_la_profesion_agregada__ek1);
		_bg___24___basic___image_ek5 = (View) findViewById(R.id._bg___24___basic___image_ek5);
		icon_ek7 = (ImageView) findViewById(R.id.icon_ek7);
		_bg__icon_container_ek1 = (View) findViewById(R.id._bg__icon_container_ek1);
		__img___1_0_icon_solid = (ImageView) findViewById(R.id.__img___1_0_icon_solid);
		__img___rectangle_10 = (ImageView) findViewById(R.id.__img___rectangle_10);
		__img___rectangle_11 = (ImageView) findViewById(R.id.__img___rectangle_11);
		titulo_ek1 = (TextView) findViewById(R.id.titulo_ek1);
		_bg__email_ek1 = (View) findViewById(R.id._bg__email_ek1);
		__img___container = (ImageView) findViewById(R.id.__img___container);
		_bg__text_ek1 = (View) findViewById(R.id._bg__text_ek1);
		email_ek2 = (TextView) findViewById(R.id.email_ek2);
	
		
		//custom code goes here
	
	}
}
	
	